COLLIGATIVE SURVIVAL — SOAL BARU

File utama: colligativ-survival-main/index.html

Isi diperbarui dengan soal baru khusus Sifat Koligatif Larutan: penurunan tekanan uap, kenaikan titik didih, penurunan titik beku, tekanan osmosis, dan faktor van’t Hoff. Mencakup pilihan ganda dan teka-teki benar/salah.

UI Retro-Tech RPG dan struktur gameplay/multiplayer dari versi UI-polished dipertahankan.

Deploy: ekstrak ZIP, lalu unggah isi folder colligativ-survival-main ke hosting/repository sesuai struktur deploy saat ini.

Penting: berkas belum diuji live terhadap Firebase/multiplayer. Uji dua pemain di room yang sama sebelum dipakai untuk demo.
